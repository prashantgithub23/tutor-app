# Files changed in this update

Drop these into your existing tutor-app project, overwriting the
matching paths:

- app/tutor/students.js   (NEW) - the "Manage students" screen
- app/tutor/schedule.js   (UPDATED) - added the "Manage students" button
- schema.sql              -> apply as an ALTER, not a full re-run:

    alter table students alter column parent_id drop not null;
    alter table students add column if not exists parent_email text;

  (you've already run this in Supabase, so schema.sql here is just for
  reference / for anyone cloning the repo fresh going forward)

## After copying the files in

git add -A
git commit -m "Add student onboarding screen"
git push

Then restart the dev server:

npx expo start --tunnel --clear
