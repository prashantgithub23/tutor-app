import { useEffect, useState } from 'react';
import {
  View, Text, TextInput, FlatList, Pressable, StyleSheet, Alert,
} from 'react-native';
import { supabase } from '../../lib/supabase';

// Tutor portal: view onboarded students and add new ones.
// A student can be added before their parent has a login yet -
// parent_email is stored and linked to parent_id later once that
// parent signs up/logs in with a matching email.
export default function TutorStudents() {
  const [students, setStudents] = useState([]);
  const [name, setName] = useState('');
  const [grade, setGrade] = useState('');
  const [parentEmail, setParentEmail] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadStudents();
  }, []);

  async function loadStudents() {
    const { data, error } = await supabase
      .from('students')
      .select('id, full_name, grade, parent_email, parent_id')
      .order('created_at', { ascending: false });
    if (!error) setStudents(data ?? []);
  }

  async function addStudent() {
    if (!name.trim()) {
      Alert.alert('Missing name', "Enter the student's name.");
      return;
    }

    setSaving(true);
    const { data: { session } } = await supabase.auth.getSession();

    const { error } = await supabase.from('students').insert({
      tutor_id: session.user.id,
      full_name: name.trim(),
      grade: grade.trim() || null,
      parent_email: parentEmail.trim() || null,
    });
    setSaving(false);

    if (error) {
      Alert.alert('Could not add student', error.message);
      return;
    }

    setName('');
    setGrade('');
    setParentEmail('');
    loadStudents();
  }

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Onboard a student</Text>

      <TextInput
        style={styles.input}
        placeholder="Student name"
        value={name}
        onChangeText={setName}
      />
      <TextInput
        style={styles.input}
        placeholder="Grade (optional)"
        value={grade}
        onChangeText={setGrade}
      />
      <TextInput
        style={styles.input}
        placeholder="Parent's email (optional, links once they sign up)"
        autoCapitalize="none"
        keyboardType="email-address"
        value={parentEmail}
        onChangeText={setParentEmail}
      />
      <Pressable style={styles.button} onPress={addStudent} disabled={saving}>
        <Text style={styles.buttonText}>{saving ? 'Adding...' : 'Add student'}</Text>
      </Pressable>

      <Text style={[styles.heading, { marginTop: 24 }]}>My students</Text>
      <FlatList
        data={students}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.name}>{item.full_name}</Text>
            <Text style={styles.meta}>
              {item.grade ? `${item.grade} · ` : ''}
              {item.parent_id ? 'Parent linked' : item.parent_email ? `Awaiting: ${item.parent_email}` : 'No parent email yet'}
            </Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, paddingTop: 60 },
  heading: { fontSize: 18, fontWeight: '600', marginBottom: 12 },
  input: {
    borderWidth: 1, borderColor: '#ddd', borderRadius: 8,
    padding: 12, marginBottom: 10, fontSize: 14,
  },
  button: {
    backgroundColor: '#111', borderRadius: 8, padding: 14,
    alignItems: 'center', marginTop: 4,
  },
  buttonText: { color: '#fff', fontWeight: '600' },
  card: {
    borderWidth: 1, borderColor: '#eee', borderRadius: 10,
    padding: 12, marginBottom: 8,
  },
  name: { fontSize: 14, fontWeight: '500' },
  meta: { fontSize: 12, color: '#666', marginTop: 2 },
});
